SCREEN_WIDTH = 400
SCREEN_HEIGHT = 300
SCREEN_TITLE = "Test Ball and Paddle Classes"

from ball import Ball

def update(ball):
    import arcade
    arcade.schedule(ball.advance, 1/80)

def main():
    
    """
    Test classes
    """
    import arcade


    # Open arcade window
    # with white background
    arcade.open_window(SCREEN_WIDTH, SCREEN_HEIGHT, SCREEN_TITLE)
    arcade.set_background_color(arcade.color.WHITE)
    
    b1 = Ball()
    
   
    
    b1.draw()
    update(b1)

    
    arcade.run()

    arcade.close_window()
    
if __name__ == "__main__":
    main()    